package com.beetalk.mytasks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MytasksApplicationTests {

	@Test
	void contextLoads() {
	}

}
