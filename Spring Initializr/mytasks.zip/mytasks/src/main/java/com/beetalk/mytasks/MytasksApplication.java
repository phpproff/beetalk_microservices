package com.beetalk.mytasks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MytasksApplication {

	public static void main(String[] args) {
		SpringApplication.run(MytasksApplication.class, args);
	}

}
