package com.beetalk.configyserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigyserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
