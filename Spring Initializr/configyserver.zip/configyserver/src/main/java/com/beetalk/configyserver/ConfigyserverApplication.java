package com.beetalk.configyserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigyserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigyserverApplication.class, args);
	}

}
